<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$pc_posts_page = (int) get_option( 'page_for_posts' );
?>
<main id="main-content" class="site-main archive-main"><div class="container">
	<header class="archive-header"><p class="eyebrow"><?php esc_html_e( 'Todas as perspectivas', 'primarius-club' ); ?></p><h1><?php echo esc_html( $pc_posts_page ? get_the_title( $pc_posts_page ) : __( 'Últimas publicações', 'primarius-club' ) ); ?></h1><p><?php esc_html_e( 'Os conteúdos mais recentes do Primarius Club, em todos os assuntos.', 'primarius-club' ); ?></p></header>
	<?php if ( have_posts() ) : ?><div class="archive-grid"><?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/post-card', null, array( 'heading' => 'h2' ) ); endwhile; ?></div><?php the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => __( '← Anteriores', 'primarius-club' ), 'next_text' => __( 'Próximas →', 'primarius-club' ) ) ); else : get_template_part( 'template-parts/empty' ); endif; ?>
</div></main>
<?php get_footer(); ?>
