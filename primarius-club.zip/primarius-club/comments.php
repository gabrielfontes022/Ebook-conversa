<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( post_password_required() ) { return; }
?>
<section id="comments" class="comments-area" aria-labelledby="comments-title">
	<h2 id="comments-title"><?php esc_html_e( 'Continue a conversa', 'primarius-club' ); ?></h2>
	<?php if ( have_comments() ) : ?>
		<ol class="comment-list"><?php wp_list_comments( array( 'style' => 'ol', 'short_ping' => true, 'avatar_size' => 0 ) ); ?></ol>
		<?php the_comments_pagination( array( 'prev_text' => __( '← Comentários anteriores', 'primarius-club' ), 'next_text' => __( 'Próximos comentários →', 'primarius-club' ) ) ); ?>
	<?php endif; ?>
	<?php if ( ! comments_open() && get_comments_number() ) : ?><p class="no-comments"><?php esc_html_e( 'Os comentários desta publicação estão encerrados.', 'primarius-club' ); ?></p><?php endif; ?>
	<?php comment_form( array( 'title_reply' => __( 'Compartilhe sua perspectiva', 'primarius-club' ), 'label_submit' => __( 'Enviar comentário', 'primarius-club' ), 'class_submit' => 'submit button' ) ); ?>
</section>
