<?php if ( ! defined( 'ABSPATH' ) ) { exit; } get_header(); ?>
<main id="main-content" class="site-main archive-main"><div class="container"><header class="archive-header"><?php pc_breadcrumbs(); ?><p class="eyebrow"><?php esc_html_e( 'Arquivo do blog', 'primarius-club' ); ?></p><h1><?php echo wp_kses_post( get_the_archive_title() ); ?></h1><?php the_archive_description( '<div class="archive-description">', '</div>' ); ?></header>
<?php if ( have_posts() ) : ?><div class="archive-grid"><?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/post-card', null, array( 'heading' => 'h2' ) ); endwhile; ?></div><?php the_posts_pagination( array( 'prev_text' => __( '← Anteriores', 'primarius-club' ), 'next_text' => __( 'Próximas →', 'primarius-club' ) ) ); else : get_template_part( 'template-parts/empty' ); endif; ?>
</div></main>
<?php get_footer(); ?>
