<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main id="main-content" class="site-main archive-main"><div class="container"><header class="archive-header"><p class="eyebrow"><?php esc_html_e( 'Explore o blog', 'primarius-club' ); ?></p><h1><?php esc_html_e( 'Publicações', 'primarius-club' ); ?></h1></header>
<?php if ( have_posts() ) : ?><div class="archive-grid"><?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/post-card', null, array( 'heading' => 'h2' ) ); endwhile; ?></div><?php the_posts_pagination( array( 'prev_text' => __( '← Anteriores', 'primarius-club' ), 'next_text' => __( 'Próximas →', 'primarius-club' ) ) ); else : get_template_part( 'template-parts/empty' ); endif; ?>
</div></main>
<?php get_footer(); ?>
