<?php if ( ! defined( 'ABSPATH' ) ) { exit; } $pc_search_id = wp_unique_id( 'pc-search-' ); ?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $pc_search_id ); ?>"><?php esc_html_e( 'Pesquisar no blog', 'primarius-club' ); ?></label>
	<div class="search-field-wrap"><input id="<?php echo esc_attr( $pc_search_id ); ?>" type="search" class="search-field" placeholder="<?php esc_attr_e( 'O que você quer descobrir?', 'primarius-club' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" name="s" required></div>
	<button type="submit" class="search-submit button"><?php echo pc_icon( 'search' ); ?><span><?php esc_html_e( 'Pesquisar', 'primarius-club' ); ?></span></button>
</form>
