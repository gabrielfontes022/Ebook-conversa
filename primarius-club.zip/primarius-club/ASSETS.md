# Identidade e ilustrações do tema

As artes deste diretório foram desenhadas para o Primarius Club. São SVG estáticos, sem JavaScript, fotografias de terceiros, URLs externas ou dependências de serviços de imagem.

## Marca

- `assets/images/logo.svg`: assinatura horizontal Primarius Club, `viewBox="0 0 450 96"`.
- `assets/images/logo-inverse.svg`: versão da assinatura para o rodapé escuro, preservando o contraste do símbolo.
- `assets/images/mark.svg`: símbolo P, `viewBox="0 0 96 96"`.
- `assets/images/favicon.svg`: mesmo símbolo em formato vetorial compacto.
- Cores gerais: azul profundo `#172B3A`, verde petróleo `#176B61` e branco quente `#FAFAF7`. O ponto do símbolo usa `#5BAF98`.
- O nome Primarius foi convertido em contornos a partir de EB Garamond Semibold; CLUB é desenhado com traços vetoriais. A marca não carrega arquivo de fonte no navegador.
- A licença SIL Open Font License da EB Garamond está preservada em `assets/images/EBGaramond-OFL.txt`.

O logo é utilizado diretamente como um arquivo do tema. Não é necessário habilitar envio genérico de SVG na Biblioteca de Mídia para utilizar a assinatura incluída.

## Capas de categoria

Todas têm `viewBox="0 0 1000 600"`. A área mais detalhada fica à direita, deixando espaço visual para título e descrição na composição do hero. As cores são compartilhadas com a configuração das categorias:

| Slug/arquivo | Acento | Linguagem visual |
| --- | --- | --- |
| `casa-e-jardim.svg` | `#287451` | Casa, janela, folhas e vaso |
| `ciencia.svg` | `#235BB0` | Órbitas e observação microscópica abstrata |
| `concursos-publicos.svg` | `#42568F` | Checklist, livros e arquitetura pública |
| `inovacao-tecnologica.svg` | `#6D4ACF` | Circuitos, conexões e chip |
| `negocios.svg` | `#A85C28` | Arquitetura de dados e gráfico abstrato |
| `politica.svg` | `#9F4253` | Arquitetura cívica e diálogo, sem referência partidária |
| `viral.svg` | `#C44E3E` | Mensagens, mídia e conexões |

Arquivos em `assets/images/categories/`. Não representam fatos, pesquisas, instituições, marcas comerciais ou resultados financeiros reais: são ilustrações decorativas de interface.

O texto da categoria Viral usa o tom mais escuro `#B54838`; a ilustração preserva o coral `#C44E3E`. Os acentos originais têm contraste calculado entre 4,66:1 e 7,10:1 sobre branco puro. Em fundos coloridos ou com transparência, confira a combinação específica. Para texto pequeno em superfícies suaves, o azul profundo é a cor principal de leitura; não dependa somente da cor para identificar a categoria.

## Fallback de publicação

`assets/images/fallback.svg` e sua cópia `assets/images/categories/geral.svg`, com `viewBox="0 0 1200 800"`, oferece uma imagem editorial neutra quando não há imagem destacada ou imagem apropriada no conteúdo. Não é fotografia de uma notícia e não deve ser descrita como tal.

## Uso e acessibilidade

- Use `alt="Primarius Club"` na marca quando ela for o único conteúdo do link inicial. Evite repetir o nome se houver texto equivalente no mesmo link.
- Capas decorativas posicionadas junto ao título da categoria podem usar `alt=""`; o nome da categoria já está disponível em texto real.
- Os SVG possuem título interno, mas o texto alternativo do elemento `img` deve ser definido conforme a função na página.
- As imagens dos posts reais continuam vindo do WordPress; estas artes não criam notícias nem substituem informações fornecidas pelos autores.

## Peso e verificações

Os sete SVG de categoria têm cerca de 1,6 a 1,9 KB cada. A marca horizontal tem 8,9 KB; símbolo e favicon, 368 bytes cada; fallback, cerca de 1,2 KB. Com a versão inversa da marca e a cópia de fallback geral, os treze arquivos SVG somam 33.060 bytes, sem compressão HTTP.

A sintaxe XML e a ausência de scripts ou recursos externos foram verificadas. O tema renderizado foi revisado no navegador, incluindo marca, rodapé, sete categorias e versão para celular.
