<?php
/** Base institutional pages: factual drafts for review, not legal certification. */
defined( 'ABSPATH' ) || exit;

function pc_page_definitions() {
	return array(
		'sobre' => array( 'title' => 'Sobre o Primarius Club', 'status' => 'publish', 'aliases' => array( 'sobre-nos', 'quem-somos', 'sobre-o-blog' ) ),
		'contato' => array( 'title' => 'Contato', 'status' => 'publish', 'aliases' => array( 'fale-conosco', 'contact' ) ),
		'privacidade' => array( 'title' => 'Política de Privacidade', 'status' => 'draft', 'aliases' => array( 'politica-de-privacidade', 'privacy-policy' ) ),
		'cookies' => array( 'title' => 'Política de Cookies', 'status' => 'draft', 'aliases' => array( 'politica-de-cookies' ) ),
		'termos' => array( 'title' => 'Termos de Uso', 'status' => 'draft', 'aliases' => array( 'termos-de-uso', 'termos-e-condicoes' ) ),
		'politica-editorial' => array( 'title' => 'Política Editorial', 'status' => 'draft', 'aliases' => array( 'linha-editorial' ) ),
	);
}

function pc_existing_page( $slug, $aliases = array() ) {
	if ( 'privacidade' === $slug ) {
		$privacy_id = absint( get_option( 'wp_page_for_privacy_policy' ) );
		$privacy = $privacy_id ? get_post( $privacy_id ) : null;
		if ( $privacy && 'page' === $privacy->post_type && 'trash' !== $privacy->post_status ) {
			return $privacy;
		}
	}
	foreach ( array_merge( array( $slug ), $aliases ) as $path ) {
		$page = get_page_by_path( $path, OBJECT, 'page' );
		if ( $page && 'trash' !== $page->post_status ) {
			return $page;
		}
	}
	return null;
}

function pc_page_content( $slug ) {
	$contents = array(
		'sobre' => '<p>O Primarius Club é um blog de assuntos diversos para quem gosta de descobrir ideias, entender o presente e ampliar o próprio olhar.</p><p>Publicamos conteúdos sobre casa e jardim, ciência, concursos públicos, inovação tecnológica, negócios, política e temas que movimentam a internet. A proposta é aproximar informação e cotidiano, com linguagem clara e contexto.</p><h2>Quem está por trás do blog</h2><p>O responsável pelo Primarius Club é [pc_owner_name]. Sugestões de pauta, dúvidas e pedidos de correção podem ser enviados pela página de contato.</p><h2>Como pensamos o conteúdo</h2><p>Valorizamos explicações compreensíveis, referências pertinentes e a distinção entre fatos, opiniões e hipóteses. A identificação das fontes e as limitações das informações devem acompanhar os conteúdos quando relevantes.</p><p>Uma publicação informativa não substitui orientação profissional individualizada nas situações que a exigem. Informações sobre editais, normas e serviços devem ser conferidas também nos canais oficiais indicados em cada publicação.</p>',
		'contato' => '<p>O Primarius Club reúne conteúdos sobre casa e jardim, ciência, concursos públicos, inovação tecnológica, negócios, política e assuntos que ganham destaque na internet.</p><p>Quer sugerir uma pauta, tirar uma dúvida, solicitar uma correção ou apresentar uma proposta de parceria? Envie sua mensagem pelo formulário abaixo. Se o contato for sobre uma publicação, inclua seu título ou endereço para facilitar o atendimento.</p>[pc_contact]',
		'privacidade' => '<p>Esta política explica o tratamento de informações no Primarius Club. O responsável pelo site é [pc_owner_name], e o contato para dúvidas e solicitações sobre dados pessoais é [pc_contact_email].</p><h2>Mensagens de contato</h2><p>Ao usar o formulário de contato, você informa nome, e-mail e o conteúdo da mensagem. Essas informações são utilizadas para receber, avaliar e responder à solicitação. Evite enviar senhas, dados bancários ou informações sensíveis que não sejam necessárias.</p><p>O formulário nativo deste tema encaminha a mensagem por e-mail e não cria um cadastro de mensagens no banco de dados do WordPress. A mensagem pode permanecer na caixa de correio utilizada pelo responsável. Um identificador técnico temporário, gerado a partir dos dados de envio, pode limitar solicitações repetidas; ele expira automaticamente. Se um plugin de formulário substituir esse recurso, suas condições de armazenamento devem ser informadas nesta página.</p><h2>Comentários e contas</h2><p>Quando habilitados, os comentários e contas de usuário são processados pelo WordPress e pelos recursos instalados no site. Dados informados, identificação técnica e registros necessários ao funcionamento podem ser armazenados. A configuração efetivamente utilizada precisa ser refletida nesta política, inclusive serviços de antispam ou avatares, se ativos.</p><h2>Publicidade e medição de audiência</h2>[pc_service_disclosure]<h2>Conteúdo incorporado e links externos</h2><p>Publicações podem conter imagens, vídeos ou outros materiais incorporados. Ao carregar conteúdo de terceiros, o navegador pode se comunicar com o respectivo fornecedor, conforme a forma de incorporação e as escolhas de privacidade aplicáveis. Os sites externos possuem suas próprias políticas.</p><h2>Hospedagem e segurança</h2><p>O provedor de hospedagem e os serviços utilizados pelo responsável podem tratar registros técnicos necessários ao funcionamento e à segurança. O tema, por si só, não instala ferramentas de publicidade, medição de audiência ou rastreamento de terceiros.</p><h2>Conservação e solicitações</h2><p>As informações devem ser conservadas pelo período necessário às finalidades informadas e às obrigações aplicáveis. Você pode usar [pc_contact_email] para solicitar esclarecimentos ou exercer direitos previstos na legislação de proteção de dados, observadas as condições legais e a verificação necessária de identidade.</p><h2>Atualizações</h2><p>Esta política deve ser revisada quando houver mudanças relevantes nos serviços, nas finalidades ou nas práticas do site.</p>',
		'cookies' => '<p>Cookies são pequenos arquivos usados por sites para manter informações de funcionamento e, conforme os serviços ativos, apoiar outras finalidades. Esta página descreve os recursos que precisam ser considerados no Primarius Club.</p><h2>Funcionamento do WordPress</h2><p>O WordPress pode utilizar cookies para autenticação de usuários e preferências de navegação, especialmente nas áreas de acesso restrito. Se houver comentários, determinados recursos também podem oferecer a opção de lembrar dados de preenchimento.</p><h2>Serviços externos</h2>[pc_service_disclosure]<p>Conteúdos incorporados e plugins podem introduzir tecnologias próprias. A relação efetiva de fornecedores, finalidades e duração dos cookies deve acompanhar a configuração real do site.</p><h2>Suas escolhas</h2><p>Você pode gerenciar cookies nas configurações do navegador e nas ferramentas de consentimento que estiverem disponíveis no site. O bloqueio de determinados cookies pode afetar recursos que dependem deles. Quando exigível, tecnologias não essenciais devem respeitar as escolhas de consentimento antes do carregamento.</p><h2>Contato</h2><p>Para dúvidas sobre o uso de cookies, entre em contato por [pc_contact_email]. O tema não inclui um gerenciador de consentimento nem carrega anúncios ou ferramentas de medição automaticamente.</p>',
		'termos' => '<p>Estes termos apresentam condições de acesso e uso do Primarius Club, blog sob responsabilidade de [pc_owner_name].</p><h2>Conteúdo informativo</h2><p>As publicações abordam assuntos diversos e têm finalidade informativa. É importante observar as datas, as fontes e os limites de cada conteúdo. Informações que dependam de normas, editais, preços ou serviços podem mudar.</p><h2>Autoria e uso dos materiais</h2><p>Os direitos sobre textos, imagens e outros materiais devem ser respeitados conforme sua autoria e licença. A presença de um conteúdo no site não autoriza sua reprodução integral. Pedidos de uso ou de correção podem ser encaminhados por [pc_contact_email]. Materiais de terceiros permanecem sujeitos às condições de seus titulares.</p><h2>Participação dos leitores</h2><p>Quando disponibilizados, comentários e mensagens devem respeitar outras pessoas, a privacidade e a legislação. Conteúdos ofensivos, fraudulentos, ilegais ou sem relação com a discussão podem ser moderados, de acordo com as regras informadas no site.</p><h2>Links e serviços externos</h2><p>Links são oferecidos para referência ou aprofundamento. A navegação para serviços de terceiros está sujeita às suas próprias condições. Relações comerciais, publicidade ou afiliação devem ser identificadas quando existentes.</p><h2>Contato e atualizações</h2><p>Para falar com o responsável, utilize [pc_contact_email]. Estes termos devem acompanhar mudanças relevantes no funcionamento e nas práticas do blog, sem afastar direitos previstos na legislação aplicável.</p>',
		'politica-editorial' => '<p>O Primarius Club aborda casa e jardim, ciência, concursos públicos, inovação tecnológica, negócios, política e assuntos em destaque. Sua proposta editorial é explicar temas com clareza, contexto e utilidade.</p><h2>Fontes e verificação</h2><p>Afirmações relevantes devem ser apoiadas por fontes pertinentes. Em temas científicos, buscamos estudos e instituições reconhecidas. Informações normativas, editais e serviços devem remeter aos documentos oficiais quando apropriado. Hipóteses, opiniões e resultados preliminares precisam ser identificados.</p><h2>Títulos, imagens e contexto</h2><p>Títulos devem representar o conteúdo sem criar promessas enganosas. Imagens ilustrativas não devem ser apresentadas como registro documental de fatos. Autoria e créditos devem ser respeitados; imagens sintéticas devem ser identificadas quando utilizadas.</p><h2>Correções</h2><p>Leitores podem indicar erros ou informações desatualizadas por [pc_contact_email], informando a publicação e o ponto a revisar. Alterações relevantes devem preservar a compreensão do contexto.</p><h2>Publicidade e independência</h2><p>Conteúdos patrocinados, anúncios e vínculos de afiliação devem ser identificados quando presentes. A existência de publicidade não deve ser confundida com endosso editorial automático de produtos ou serviços.</p><h2>Responsabilidade editorial</h2><p>O responsável pelo blog é [pc_owner_name]. Ferramentas de apoio à produção não substituem a responsabilidade sobre as informações publicadas. Esta política deve refletir as práticas efetivamente adotadas no site.</p>',
	);
	return isset( $contents[ $slug ] ) ? $contents[ $slug ] : '';
}

function pc_owner_name_shortcode() {
	$settings = pc_settings();
	return esc_html( $settings['owner_name'] );
}
add_shortcode( 'pc_owner_name', 'pc_owner_name_shortcode' );

function pc_contact_email_shortcode() {
	$settings = pc_settings();
	$email = sanitize_email( $settings['contact_email'] );
	if ( ! $email ) {
		return 'a página de contato';
	}
	return '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>';
}
add_shortcode( 'pc_contact_email', 'pc_contact_email_shortcode' );

function pc_service_disclosure_shortcode() {
	$settings = pc_settings();
	$paragraphs = array();
	if ( 'yes' === $settings['adsense'] ) {
		$paragraphs[] = '<p>O responsável informou que utiliza Google AdSense. Os fornecedores de publicidade podem tratar informações e usar cookies ou tecnologias semelhantes conforme as escolhas de consentimento e as políticas aplicáveis. Consulte também <a href="https://policies.google.com/technologies/partner-sites" rel="noopener noreferrer" target="_blank">como o Google utiliza dados em sites parceiros</a>. A identificação dos recursos efetivamente ativos e a configuração de consentimento devem ser mantidas atualizadas pelo responsável.</p>';
	}
	if ( 'yes' === $settings['analytics'] ) {
		$paragraphs[] = '<p>O responsável informou que utiliza Google Analytics para medição de audiência. O tratamento depende das opções efetivamente configuradas e das escolhas de consentimento. A finalidade, a conservação e os recursos ativos devem ser documentados conforme essa configuração. Consulte a <a href="https://policies.google.com/privacy" rel="noopener noreferrer" target="_blank">Política de Privacidade do Google</a>.</p>';
	}
	if ( 'unknown' === $settings['adsense'] || 'unknown' === $settings['analytics'] ) {
		$paragraphs[] = '<p>A utilização de serviços de publicidade ou medição de audiência ainda precisa ser confirmada pelo responsável. Esta seção deve ser revisada antes de a política ser publicada, para refletir os fornecedores e as finalidades realmente presentes no site.</p>';
	} elseif ( 'no' === $settings['adsense'] && 'no' === $settings['analytics'] ) {
		$paragraphs[] = '<p>O responsável informou não utilizar Google AdSense nem Google Analytics. Outros recursos instalados, conteúdo incorporado e serviços de hospedagem devem ser considerados separadamente nesta política.</p>';
	}
	return implode( '', $paragraphs );
}
add_shortcode( 'pc_service_disclosure', 'pc_service_disclosure_shortcode' );

/** Explicit and repeatable setup; never touches posts or existing page content. */
function pc_prepare_structure() {
	$created = array();
	foreach ( pc_categories() as $slug => $config ) {
		if ( pc_category_term( $slug ) ) {
			continue;
		}
		$result = wp_insert_term( $config['label'], 'category', array( 'slug' => $slug, 'description' => $config['description'] ) );
		if ( ! is_wp_error( $result ) ) {
			$created[] = 'Categoria: ' . $config['label'];
		}
	}
	foreach ( pc_page_definitions() as $slug => $definition ) {
		if ( pc_existing_page( $slug, $definition['aliases'] ) ) {
			continue;
		}
		$id = wp_insert_post( array(
			'post_type' => 'page', 'post_title' => $definition['title'], 'post_name' => $slug,
			'post_status' => $definition['status'], 'post_content' => pc_page_content( $slug ),
			'comment_status' => 'closed', 'ping_status' => 'closed',
		), true );
		if ( ! is_wp_error( $id ) && $id ) {
			update_post_meta( $id, '_pc_institutional_page', $slug );
			$created[] = 'Página: ' . $definition['title'];
		}
	}
	return $created;
}
