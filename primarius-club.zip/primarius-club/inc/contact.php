<?php
/** Native contact form: uses the site's mail transport, no external service. */
defined( 'ABSPATH' ) || exit;

/** Reject crafted array inputs before passing values to string sanitizers. */
function pc_form_value( $source, $key ) {
	return isset( $source[ $key ] ) && is_string( $source[ $key ] ) ? wp_unslash( $source[ $key ] ) : '';
}

function pc_contact_return_url() {
	$page = pc_existing_page( 'contato', array( 'fale-conosco', 'contact' ) );
	return $page && 'publish' === $page->post_status ? get_permalink( $page ) : home_url( '/' );
}

function pc_contact_form() {
	$settings = pc_settings();
	$shortcode = trim( $settings['contact_shortcode'] );
	$plugin_form_available = $shortcode && preg_match( '/^\[([a-zA-Z][a-zA-Z0-9_-]*)/', $shortcode, $shortcode_tag ) && shortcode_exists( $shortcode_tag[1] );
	if ( $plugin_form_available && false === stripos( $shortcode, '[pc_contact' ) ) {
		echo do_shortcode( $shortcode ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted administrator supplied shortcode; plugin owns output.
		return;
	}
	$status = sanitize_key( pc_form_value( $_GET, 'pc_contact_status' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only public status.
	$messages = array(
		'accepted' => 'Sua mensagem foi aceita pelo sistema de envio do site. A entrega depende da configuração de e-mail da hospedagem.',
		'invalid' => 'Não foi possível enviar. Confira os campos e atualize a página antes de tentar novamente.',
		'wait' => 'Aguarde alguns minutos antes de enviar outra mensagem.',
		'failed' => 'O sistema de e-mail não aceitou o envio. Tente novamente mais tarde ou use o e-mail de contato.',
	);
	if ( isset( $messages[ $status ] ) ) {
		echo '<div class="pc-form-notice pc-form-notice--' . esc_attr( $status ) . '" role="status">' . esc_html( $messages[ $status ] ) . '</div>';
	}
	echo '<form class="pc-contact-form" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" method="post">';
	echo '<input type="hidden" name="action" value="pc_contact">';
	wp_nonce_field( 'pc_contact_send', 'pc_contact_nonce' );
	echo '<input type="hidden" name="pc_return" value="' . esc_url( get_permalink() ? get_permalink() : pc_contact_return_url() ) . '">';
	echo '<div class="pc-contact-trap" aria-hidden="true" hidden><label>Deixe este campo vazio<input type="text" name="pc_website" tabindex="-1" autocomplete="off"></label></div>';
	echo '<p class="pc-form-field"><label for="pc-name">Seu nome <span aria-hidden="true">*</span></label><input id="pc-name" type="text" name="pc_name" maxlength="120" autocomplete="name" required></p>';
	echo '<p class="pc-form-field"><label for="pc-email">Seu e-mail <span aria-hidden="true">*</span></label><input id="pc-email" type="email" name="pc_email" maxlength="190" autocomplete="email" required></p>';
	echo '<p class="pc-form-field"><label for="pc-subject">Assunto <span aria-hidden="true">*</span></label><input id="pc-subject" type="text" name="pc_subject" maxlength="160" required></p>';
	echo '<p class="pc-form-field"><label for="pc-message">Sua mensagem <span aria-hidden="true">*</span></label><textarea id="pc-message" name="pc_message" rows="7" minlength="10" maxlength="10000" required></textarea></p>';
	echo '<p class="pc-form-help">Os campos marcados são necessários para receber e responder à sua mensagem. Não envie senhas ou dados sensíveis.</p>';
	$privacy_url = get_privacy_policy_url();
	if ( $privacy_url ) {
		echo '<p class="pc-form-help">Saiba como as informações são tratadas na <a href="' . esc_url( $privacy_url ) . '">Política de Privacidade</a>.</p>';
	}
	echo '<p><button class="pc-button" type="submit">Enviar mensagem ' . pc_icon( 'arrow' ) . '</button></p></form>';
	if ( is_email( $settings['contact_email'] ) ) {
		echo '<p class="pc-contact-alternative">Se preferir, escreva para <a href="mailto:' . esc_attr( $settings['contact_email'] ) . '">' . esc_html( $settings['contact_email'] ) . '</a>.</p>';
	}
}

function pc_contact_shortcode() {
	ob_start();
	pc_contact_form();
	return ob_get_clean();
}
add_shortcode( 'pc_contact', 'pc_contact_shortcode' );

function pc_contact_redirect( $status ) {
	$fallback = pc_contact_return_url();
	$return = esc_url_raw( pc_form_value( $_POST, 'pc_return' ) );
	$return = wp_validate_redirect( $return, $fallback );
	$return = remove_query_arg( 'pc_contact_status', $return );
	wp_safe_redirect( add_query_arg( 'pc_contact_status', sanitize_key( $status ), $return ) );
	exit;
}

function pc_handle_contact() {
	if ( 'POST' !== strtoupper( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) ) {
		pc_contact_redirect( 'invalid' );
	}
	$nonce = sanitize_text_field( pc_form_value( $_POST, 'pc_contact_nonce' ) );
	if ( ! wp_verify_nonce( $nonce, 'pc_contact_send' ) ) {
		pc_contact_redirect( 'invalid' );
	}
	$trap = trim( pc_form_value( $_POST, 'pc_website' ) );
	if ( '' !== $trap ) {
		pc_contact_redirect( 'invalid' );
	}
	$name = sanitize_text_field( pc_form_value( $_POST, 'pc_name' ) );
	$email = sanitize_email( pc_form_value( $_POST, 'pc_email' ) );
	$subject = sanitize_text_field( pc_form_value( $_POST, 'pc_subject' ) );
	$message = sanitize_textarea_field( pc_form_value( $_POST, 'pc_message' ) );
	if ( ! $name || strlen( $name ) > 480 || ! is_email( $email ) || strlen( $email ) > 190 || ! $subject || strlen( $subject ) > 640 || strlen( $message ) < 10 || strlen( $message ) > 40000 ) {
		pc_contact_redirect( 'invalid' );
	}
	$address = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$rate_key = 'pc_contact_' . substr( wp_hash( strtolower( $email ) . '|' . $address ), 0, 32 );
	$ip_key = 'pc_contact_ip_' . substr( wp_hash( $address ), 0, 32 );
	$ip_attempts = (int) get_transient( $ip_key );
	if ( get_transient( $rate_key ) || $ip_attempts >= 10 ) {
		pc_contact_redirect( 'wait' );
	}
	set_transient( $rate_key, 1, 2 * MINUTE_IN_SECONDS );
	set_transient( $ip_key, $ip_attempts + 1, 10 * MINUTE_IN_SECONDS );
	$settings = pc_settings();
	$recipient = is_email( $settings['contact_email'] ) ? $settings['contact_email'] : get_option( 'admin_email' );
	if ( ! is_email( $recipient ) ) {
		pc_contact_redirect( 'failed' );
	}
	$body = "Mensagem enviada pelo formulário do Primarius Club.\n\nNome: " . $name . "\nE-mail: " . $email . "\nAssunto: " . $subject . "\n\n" . $message;
	$headers = array( 'Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $email );
	$accepted = wp_mail( $recipient, '[Primarius Club] ' . $subject, $body, $headers );
	pc_contact_redirect( $accepted ? 'accepted' : 'failed' );
}
add_action( 'admin_post_pc_contact', 'pc_handle_contact' );
add_action( 'admin_post_nopriv_pc_contact', 'pc_handle_contact' );
