<?php
/** Optional, capability-checked onboarding and factual site settings. */
defined( 'ABSPATH' ) || exit;

function pc_admin_menu() {
	add_theme_page( 'Primarius Club', 'Primarius Club', 'manage_options', 'primarius-club', 'pc_render_admin_page' );
}
add_action( 'admin_menu', 'pc_admin_menu' );

function pc_sanitize_settings( $input ) {
	$input = is_array( $input ) ? $input : array();
	$current = pc_settings();
	$owner = isset( $input['owner_name'] ) && is_string( $input['owner_name'] ) ? sanitize_text_field( $input['owner_name'] ) : $current['owner_name'];
	$email = isset( $input['contact_email'] ) && is_string( $input['contact_email'] ) ? sanitize_email( $input['contact_email'] ) : '';
	if ( ! is_email( $email ) ) {
		add_settings_error( 'pc_settings', 'pc_email_invalid', 'Informe um e-mail de contato válido. O endereço anterior foi preservado.' );
		$email = $current['contact_email'];
	}
	$shortcode = isset( $input['contact_shortcode'] ) && is_string( $input['contact_shortcode'] ) ? trim( sanitize_text_field( $input['contact_shortcode'] ) ) : '';
	if ( $shortcode && ( strlen( $shortcode ) > 500 || ! preg_match( '/^\[[a-zA-Z][a-zA-Z0-9_-]*(?:[^\]<>]*)\]$/', $shortcode ) || false !== stripos( $shortcode, '[pc_contact' ) ) ) {
		add_settings_error( 'pc_settings', 'pc_shortcode_invalid', 'Use somente o shortcode de abertura de um formulário instalado, por exemplo [wpforms id="123"]. O formulário nativo será usado se este campo ficar vazio.' );
		$shortcode = '';
	}
	if ( $shortcode && preg_match( '/^\[([a-zA-Z][a-zA-Z0-9_-]*)/', $shortcode, $tag ) && ! shortcode_exists( $tag[1] ) ) {
		add_settings_error( 'pc_settings', 'pc_shortcode_missing', 'O shortcode não está disponível entre os plugins ativos. O formulário nativo foi mantido; ative o plugin antes de selecionar seu formulário.' );
		$shortcode = '';
	}
	$services = array();
	foreach ( array( 'adsense', 'analytics' ) as $service ) {
		$value = isset( $input[ $service ] ) && is_string( $input[ $service ] ) ? $input[ $service ] : 'unknown';
		$services[ $service ] = in_array( $value, array( 'unknown', 'yes', 'no' ), true ) ? $value : 'unknown';
	}
	return array(
		'owner_name' => $owner ? $owner : $current['owner_name'],
		'contact_email' => $email, 'contact_shortcode' => $shortcode,
		'adsense' => $services['adsense'], 'analytics' => $services['analytics'],
	);
}

function pc_register_settings() {
	register_setting( 'pc_settings_group', 'pc_settings', array( 'type' => 'array', 'sanitize_callback' => 'pc_sanitize_settings', 'default' => array() ) );
}
add_action( 'admin_init', 'pc_register_settings' );

function pc_theme_notice() {
	if ( ! current_user_can( 'manage_options' ) || ! get_transient( 'pc_theme_setup_notice' ) ) {
		return;
	}
	echo '<div class="notice notice-info is-dismissible"><p><strong>Primarius Club:</strong> o tema preservou seus posts e configurações. Revise as opções e prepare as categorias e páginas em <a href="' . esc_url( admin_url( 'themes.php?page=primarius-club' ) ) . '">Aparência → Primarius Club</a>.</p></div>';
	delete_transient( 'pc_theme_setup_notice' );
}
add_action( 'admin_notices', 'pc_theme_notice' );

function pc_setup_structure_action() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Você não tem permissão para preparar a estrutura deste site.', 403 );
	}
	check_admin_referer( 'pc_prepare_structure', 'pc_setup_nonce' );
	$created = pc_prepare_structure();
	set_transient( 'pc_setup_result_' . get_current_user_id(), $created, 5 * MINUTE_IN_SECONDS );
	wp_safe_redirect( add_query_arg( 'pc_prepared', '1', admin_url( 'themes.php?page=primarius-club' ) ) );
	exit;
}
add_action( 'admin_post_pc_prepare_structure', 'pc_setup_structure_action' );

function pc_set_privacy_action() {
	if ( ! current_user_can( 'manage_privacy_options' ) && ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Você não tem permissão para alterar a página de privacidade.', 403 );
	}
	check_admin_referer( 'pc_set_privacy', 'pc_privacy_nonce' );
	$page = pc_existing_page( 'privacidade', array( 'politica-de-privacidade', 'privacy-policy' ) );
	if ( $page && 'publish' === $page->post_status ) {
		update_option( 'wp_page_for_privacy_policy', $page->ID );
	}
	wp_safe_redirect( admin_url( 'themes.php?page=primarius-club' ) );
	exit;
}
add_action( 'admin_post_pc_set_privacy', 'pc_set_privacy_action' );

function pc_render_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$settings = pc_settings();
	$result_key = 'pc_setup_result_' . get_current_user_id();
	$result = get_transient( $result_key );
	delete_transient( $result_key );
	?>
	<div class="wrap">
		<h1>Primarius Club Editorial</h1>
		<p>Seu conteúdo continua sendo administrado em <strong>Posts</strong>. O tema mostra automaticamente as publicações, imagens e categorias existentes. Nenhum post demonstrativo é criado.</p>
		<?php settings_errors( 'pc_settings' ); ?>
		<?php if ( is_array( $result ) ) : ?>
			<div class="notice notice-success"><p><?php echo $result ? esc_html( 'Estrutura preparada. Foram criados ' . count( $result ) . ' itens que ainda não existiam.' ) : 'A estrutura já estava preparada. Nenhum conteúdo existente foi alterado.'; ?></p></div>
		<?php endif; ?>
		<h2>1. Dados do responsável</h2>
		<form action="options.php" method="post">
			<?php settings_fields( 'pc_settings_group' ); ?>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="pc-owner">Nome do responsável</label></th><td><input class="regular-text" id="pc-owner" name="pc_settings[owner_name]" type="text" maxlength="120" value="<?php echo esc_attr( $settings['owner_name'] ); ?>" required></td></tr>
				<tr><th scope="row"><label for="pc-email">E-mail público de contato</label></th><td><input class="regular-text" id="pc-email" name="pc_settings[contact_email]" type="email" value="<?php echo esc_attr( $settings['contact_email'] ); ?>" required><p class="description">Usado nas páginas institucionais e como destinatário do formulário nativo.</p></td></tr>
				<tr><th scope="row"><label for="pc-shortcode">Formulário de um plugin (opcional)</label></th><td><input class="large-text code" id="pc-shortcode" name="pc_settings[contact_shortcode]" type="text" value="<?php echo esc_attr( $settings['contact_shortcode'] ); ?>"><p class="description">Cole o shortcode de um plugin que você já instalou ou deixe vazio para usar o formulário nativo. O envio nativo depende do serviço de e-mail da hospedagem; faça um envio de teste e confira o recebimento.</p></td></tr>
				<?php foreach ( array( 'adsense' => 'Google AdSense', 'analytics' => 'Google Analytics' ) as $key => $label ) : ?>
				<tr><th scope="row"><label for="pc-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th><td><select id="pc-<?php echo esc_attr( $key ); ?>" name="pc_settings[<?php echo esc_attr( $key ); ?>]"><option value="unknown" <?php selected( $settings[ $key ], 'unknown' ); ?>>Ainda não confirmado</option><option value="yes" <?php selected( $settings[ $key ], 'yes' ); ?>>Uso este serviço</option><option value="no" <?php selected( $settings[ $key ], 'no' ); ?>>Não uso este serviço</option></select><p class="description">Esta declaração orienta os textos institucionais. Ela não instala nem remove o serviço, não insere rastreamento e não substitui a configuração de consentimento.</p></td></tr>
				<?php endforeach; ?>
			</table>
			<?php submit_button( 'Salvar informações' ); ?>
		</form>
		<hr>
		<h2>2. Preparar categorias e páginas</h2>
		<p>Cria apenas o que ainda não existe e reconhece os nomes alternativos mais comuns de categorias e páginas. Posts, menus, textos e configurações existentes são preservados.</p>
		<p><strong>Sobre e Contato</strong> são criados como páginas públicas. <strong>Privacidade, Cookies, Termos e Política Editorial</strong> são criados como rascunhos para você conferir antes de publicar. Os dados de serviços externos ainda não confirmados não são apresentados como uso ativo.</p>
		<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><input type="hidden" name="action" value="pc_prepare_structure"><?php wp_nonce_field( 'pc_prepare_structure', 'pc_setup_nonce' ); ?><?php submit_button( 'Preparar estrutura sem substituir conteúdo', 'secondary', 'submit', false ); ?></form>
		<h3>Páginas institucionais</h3>
		<table class="widefat striped"><thead><tr><th>Página</th><th>Situação</th><th>Ação</th></tr></thead><tbody>
		<?php foreach ( pc_page_definitions() as $slug => $definition ) : $page = pc_existing_page( $slug, $definition['aliases'] ); ?>
			<tr><td><?php echo esc_html( $definition['title'] ); ?></td><td><?php echo $page ? ( 'publish' === $page->post_status ? 'Publicada' : 'Revisão pendente / rascunho' ) : 'Ainda não criada'; ?></td><td><?php if ( $page ) : ?><a href="<?php echo esc_url( get_edit_post_link( $page->ID ) ); ?>">Revisar conteúdo</a><?php if ( 'publish' === $page->post_status ) : ?> · <a href="<?php echo esc_url( get_permalink( $page ) ); ?>">Ver página</a><?php endif; ?><?php else : ?>Use o botão acima<?php endif; ?></td></tr>
		<?php endforeach; ?>
		</tbody></table>
		<p>Esses textos são uma base editorial. Confira plugins, fornecedores, práticas de dados e informações reais antes de publicar as políticas. O tema não oferece certificação jurídica nem garantia de aprovação no AdSense.</p>
		<?php $privacy = pc_existing_page( 'privacidade', array( 'politica-de-privacidade', 'privacy-policy' ) ); if ( $privacy && 'publish' === $privacy->post_status ) : ?>
		<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><input type="hidden" name="action" value="pc_set_privacy"><?php wp_nonce_field( 'pc_set_privacy', 'pc_privacy_nonce' ); ?><?php submit_button( 'Definir esta página como Política de Privacidade do WordPress', 'secondary', 'submit', false ); ?></form>
		<?php endif; ?>
		<hr>
		<h2>3. Ajustar apresentação</h2>
		<p>Escolha a página inicial em <a href="<?php echo esc_url( admin_url( 'options-reading.php' ) ); ?>">Configurações → Leitura</a>. Para exibir as publicações na capa, selecione “Seus posts recentes”. O tema também oferece seu modelo de capa quando uma página inicial estática é escolhida.</p>
		<p>A navegação padrão já mostra as sete categorias. Para personalizar links, use <a href="<?php echo esc_url( admin_url( 'nav-menus.php' ) ); ?>">Aparência → Menus</a> e a posição “Navegação principal”. Os links de rodapé publicados são reconhecidos automaticamente ou podem ser personalizados na posição “Links do rodapé”.</p>
		<p>Defina uma <strong>Imagem destacada</strong> em cada post para obter a melhor apresentação. Sem ela, o tema tenta usar a primeira imagem do conteúdo; na ausência de ambas, mostra uma ilustração leve da categoria. As ilustrações não alteram os créditos das imagens dos seus posts.</p>
	</div>
	<?php
}
