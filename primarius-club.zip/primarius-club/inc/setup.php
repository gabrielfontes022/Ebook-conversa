<?php
/** Theme registration. Activation does not replace the site's settings. */
defined( 'ABSPATH' ) || exit;

function pc_theme_setup() {
	load_theme_textdomain( 'primarius-club', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'custom-logo', array( 'height' => 100, 'width' => 440, 'flex-height' => true, 'flex-width' => true ) );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_image_size( 'pc-feature', 1400, 900, true );
	add_image_size( 'pc-card', 680, 440, true );
	add_image_size( 'pc-thumb', 320, 210, true );
	register_nav_menus( array( 'primary' => 'Navegação principal', 'footer' => 'Links do rodapé' ) );
	add_editor_style( 'assets/css/editor.css' );
	$GLOBALS['content_width'] = 780;
}
add_action( 'after_setup_theme', 'pc_theme_setup' );

function pc_enqueue_assets() {
	$css = get_theme_file_path( '/assets/css/main.css' );
	$js = get_theme_file_path( '/assets/js/main.js' );
	wp_enqueue_style( 'pc-main', get_theme_file_uri( '/assets/css/main.css' ), array(), file_exists( $css ) ? (string) filemtime( $css ) : PC_THEME_VERSION );
	wp_enqueue_script( 'pc-main', get_theme_file_uri( '/assets/js/main.js' ), array(), file_exists( $js ) ? (string) filemtime( $js ) : PC_THEME_VERSION, true );
	wp_script_add_data( 'pc-main', 'strategy', 'defer' );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	$config = pc_category_config();
	$css_vars = sprintf( ':root{--category-accent:%1$s;--category-tint:%2$s;--topic-accent:%1$s;--topic-tint:%2$s}', sanitize_hex_color( $config['accent'] ), sanitize_hex_color( $config['tint'] ) );
	wp_add_inline_style( 'pc-main', $css_vars );
}
add_action( 'wp_enqueue_scripts', 'pc_enqueue_assets' );

function pc_body_classes( $classes ) {
	$config = pc_category_config();
	$classes[] = 'pc-theme';
	$classes[] = 'pc-category-' . sanitize_html_class( $config['slug'] );
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'pc-no-sidebar';
	}
	return $classes;
}
add_filter( 'body_class', 'pc_body_classes' );

function pc_widgets_init() {
	register_sidebar( array(
		'name' => 'Após o conteúdo', 'id' => 'after-content',
		'description' => 'Blocos opcionais após os artigos. O tema não carrega anúncios por conta própria.',
		'before_widget' => '<section id="%1$s" class="pc-widget %2$s">', 'after_widget' => '</section>',
		'before_title' => '<h2 class="pc-widget-title">', 'after_title' => '</h2>',
	) );
}
add_action( 'widgets_init', 'pc_widgets_init' );

function pc_after_switch_theme() {
	set_transient( 'pc_theme_setup_notice', 1, DAY_IN_SECONDS );
}
add_action( 'after_switch_theme', 'pc_after_switch_theme' );
