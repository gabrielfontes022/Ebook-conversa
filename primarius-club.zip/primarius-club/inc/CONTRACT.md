# Core helpers and template contract

- `pc_categories()` returns an associative catalog keyed by the seven canonical slugs. Each item: `slug`, `label`, `description`, `accent`, `tint`, `aliases`, `image` (URL).
- `pc_category_key($term)` accepts WP_Term, term ID, slug or label; returns canonical key or empty string.
- `pc_category_terms($key)` returns existing WP_Term objects for canonical + aliases. Use their IDs in category `tax_query` to aggregate legacy terms without migrating posts.
- `pc_category_term($key)` chooses a populated term, preferring canonical where applicable. `pc_category_link($key)` links its real archive; if no term exists yet, links to a valid WordPress search until optional setup.
- `pc_category_config($term=null)` resolves known config; null uses current category or primary post category. Adds `term` (WP_Term|null) and `term_id` (0 if absent). Unknown/default uses key `geral`.
- `pc_primary_category($post_id=null)` returns WP_Term|null, respecting Yoast primary category when available.
- `pc_reading_time($post_id=null)` returns integer minutes >=1. `pc_excerpt($length=28,$post_id=null)` returns plain string; template must escape it.
- `pc_post_image($size='pc-card',$args=[])` **prints** image markup; args: `post_id`, `class`, `loading` (`lazy` default / `eager`), `fetchpriority` (`high` optional). Uses featured attachment, first suitable content image, or category SVG; source credits remain with the existing content. Native attachment output includes srcset/sizes.
- `pc_brand_markup($inverse=false)` **prints** homepage link/logo. Custom WordPress logo preferred; otherwise `assets/images/logo.svg`, with text fallback.
- `pc_icon($name,$class='')` **returns** safe constant SVG. Names: search, menu, close, arrow, clock, chevron, mail.
- `pc_breadcrumbs()` **prints** semantic non-schema breadcrumbs; does not duplicate Yoast structured data.
- `pc_institutional_pages()` returns only published page links with `title,url,id,slug`; existing aliases/privacy WordPress setting respected.
- `pc_contact_form()` **prints** native contact form or trusted administrator's plugin shortcode. `[pc_contact]` shortcode also available. Never render both shortcode and form template on same page.
- `pc_settings()` defaults: Gabriel Fontes, primariusclub@gmail.com. Service disclosures are tri-state unknown/yes/no; theme never loads Ads/Analytics itself.

Assets: `assets/images/categories/{canonical-slug}.svg`, plus `geral.svg`; logo `assets/images/logo.svg`. CSS vars `--category-accent`, `--category-tint`, `--topic-accent`, `--topic-tint` supplied for current context. Body classes include `pc-theme`, `pc-category-{slug}`.

Activation only shows admin notice. Optional structure setup requires explicit administrator click, nonce and capability; does not overwrite content, create demo posts, change front-page settings or replace menus. About/Contact are published if newly created; policy pages are drafts pending factual review. Form uses WordPress wp_mail, anti-CSRF nonce, honeypot and short-lived rate limit, without claiming delivery or eliminating spam. Deployment must verify actual mail delivery.
