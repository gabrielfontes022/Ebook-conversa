<?php
/** Category identity and compatibility with existing WordPress terms. */
defined( 'ABSPATH' ) || exit;

/**
 * The catalog controls presentation; existing categories remain untouched.
 *
 * @return array<string,array>
 */
function pc_categories() {
	$catalog = array(
		'casa-e-jardim' => array(
			'label' => 'Casa e Jardim',
			'description' => 'Ideias para cuidar dos espaços, cultivar o verde e viver melhor em casa.',
			'accent' => '#287451', 'tint' => '#EDF3E7',
			'aliases' => array( 'casa-jardim', 'casa', 'jardim', 'decoracao' ),
		),
		'ciencia' => array(
			'label' => 'Ciência',
			'description' => 'Descobertas, perguntas e evidências para compreender o mundo com mais clareza.',
			'accent' => '#235BB0', 'tint' => '#EBF1FC',
			'aliases' => array( 'ciencias', 'ciencia-e-pesquisa' ),
		),
		'concursos-publicos' => array(
			'label' => 'Concursos Públicos',
			'description' => 'Informação, estudo e preparação para construir seus próximos passos.',
			'accent' => '#42568F', 'tint' => '#EDF0F8',
			'aliases' => array( 'concurso-publico', 'concursos', 'concurso' ),
		),
		'inovacao-tecnologica' => array(
			'label' => 'Inovação Tecnológica',
			'description' => 'Tecnologias, ideias e mudanças que já começam a transformar o cotidiano.',
			'accent' => '#6D4ACF', 'tint' => '#F1EBF9',
			'aliases' => array( 'inovacao-e-tecnologia', 'inovacao', 'tecnologia', 'tecnologias', 'ciencia-e-tecnologia', 'ciencia-e-tecnologias' ),
		),
		'negocios' => array(
			'label' => 'Negócios',
			'description' => 'Contexto e novas perspectivas sobre empresas, trabalho e decisões de negócio.',
			'accent' => '#A85C28', 'tint' => '#F8EEE5',
			'aliases' => array( 'negocio', 'empreendedorismo', 'economia-e-negocios' ),
		),
		'politica' => array(
			'label' => 'Política',
			'description' => 'Debates, instituições e decisões públicas explicados com contexto.',
			'accent' => '#9F4253', 'tint' => '#FAECF0',
			'aliases' => array( 'politicas', 'politica-nacional' ),
		),
		'viral' => array(
			'label' => 'Viral',
			'description' => 'O que movimenta as conversas na internet, com curiosidade e atenção ao contexto.',
			'accent' => '#B54838', 'tint' => '#FCEDE8',
			'aliases' => array( 'virais', 'em-alta', 'tendencias', 'viralizou' ),
		),
	);

	foreach ( $catalog as $slug => &$config ) {
		$config['slug'] = $slug;
		$config['image'] = get_theme_file_uri( '/assets/images/categories/' . $slug . '.svg' );
	}
	unset( $config );
	return $catalog;
}

/** Canonical key for an existing category, known slug, ID, or label. */
function pc_category_key( $term ) {
	$catalog = pc_categories();
	if ( is_numeric( $term ) ) {
		$term = get_term( (int) $term, 'category' );
	}
	if ( is_wp_error( $term ) ) {
		return '';
	}
	$slug = $term instanceof WP_Term ? $term->slug : sanitize_title( (string) $term );
	foreach ( $catalog as $key => $config ) {
		if ( $key === $slug || in_array( $slug, $config['aliases'], true ) || sanitize_title( $config['label'] ) === $slug ) {
			return $key;
		}
	}
	return '';
}

/** All existing terms for a category identity, including legacy aliases. */
function pc_category_terms( $key ) {
	$catalog = pc_categories();
	$key = pc_category_key( $key );
	if ( ! $key || ! isset( $catalog[ $key ] ) ) {
		return array();
	}
	$terms = get_terms( array(
		'taxonomy' => 'category',
		'hide_empty' => false,
		'slug' => array_merge( array( $key ), $catalog[ $key ]['aliases'] ),
	) );
	return is_wp_error( $terms ) ? array() : $terms;
}

/** Prefer a populated canonical term, otherwise a populated legacy term. */
function pc_category_term( $key ) {
	$terms = pc_category_terms( $key );
	if ( ! $terms ) {
		return null;
	}
	$key = pc_category_key( $key );
	usort( $terms, function ( $a, $b ) use ( $key ) {
		if ( (bool) $a->count !== (bool) $b->count ) {
			return $a->count ? -1 : 1;
		}
		if ( ( $a->slug === $key ) !== ( $b->slug === $key ) ) {
			return $a->slug === $key ? -1 : 1;
		}
		return (int) $b->count - (int) $a->count;
	} );
	return reset( $terms );
}

/** Resolve presentation data. Does not change or create WordPress terms. */
function pc_category_config( $term = null ) {
	if ( null === $term ) {
		$term = is_category() ? get_queried_object() : pc_primary_category();
	}
	$key = pc_category_key( $term );
	if ( ! $key ) {
		return array(
			'slug' => 'geral', 'label' => $term instanceof WP_Term ? $term->name : 'Primarius Club',
			'description' => 'Informação, contexto e novas perspectivas para ampliar o seu olhar.',
			'accent' => '#176B61', 'tint' => '#E5F2EE', 'aliases' => array(),
			'image' => get_theme_file_uri( '/assets/images/categories/geral.svg' ),
			'term' => $term instanceof WP_Term ? $term : null,
			'term_id' => $term instanceof WP_Term ? (int) $term->term_id : 0,
		);
	}
	$catalog = pc_categories();
	$config = $catalog[ $key ];
	$resolved = $term instanceof WP_Term ? $term : pc_category_term( $key );
	$config['term'] = $resolved;
	$config['term_id'] = $resolved ? (int) $resolved->term_id : 0;
	return $config;
}

/** Respect Yoast's chosen primary category when available. */
function pc_primary_category( $post_id = null ) {
	$post_id = $post_id ? absint( $post_id ) : get_the_ID();
	$terms = get_the_category( $post_id );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return null;
	}
	if ( class_exists( 'WPSEO_Primary_Term' ) ) {
		$primary = new WPSEO_Primary_Term( 'category', $post_id );
		$primary_id = $primary->get_primary_term();
		if ( ! is_wp_error( $primary_id ) ) {
			foreach ( $terms as $term ) {
				if ( (int) $term->term_id === (int) $primary_id ) {
					return $term;
				}
			}
		}
	}
	foreach ( $terms as $term ) {
		if ( pc_category_key( $term ) ) {
			return $term;
		}
	}
	return reset( $terms );
}

/** Search is a valid temporary destination before the optional structure setup. */
function pc_category_link( $key ) {
	$term = pc_category_term( $key );
	if ( $term ) {
		$url = get_category_link( $term->term_id );
		if ( ! is_wp_error( $url ) ) {
			return $url;
		}
	}
	$config = pc_category_config( $key );
	return add_query_arg( 's', $config['label'], home_url( '/' ) );
}
