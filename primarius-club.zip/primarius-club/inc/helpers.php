<?php
/** Presentation helpers with escaped output. */
defined( 'ABSPATH' ) || exit;

function pc_settings() {
	$defaults = array(
		'owner_name' => 'Gabriel Fontes',
		'contact_email' => 'primariusclub@gmail.com',
		'contact_shortcode' => '',
		'adsense' => 'unknown',
		'analytics' => 'unknown',
	);
	$saved = get_option( 'pc_settings', array() );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
}

function pc_reading_time( $post_id = null ) {
	$post = get_post( $post_id ? $post_id : get_the_ID() );
	if ( ! $post ) {
		return 1;
	}
	$text = wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
	preg_match_all( '/[\p{L}\p{N}]+(?:[’\'-][\p{L}\p{N}]+)*/u', $text, $words );
	return max( 1, (int) ceil( count( $words[0] ) / 220 ) );
}

function pc_excerpt( $length = 28, $post_id = null ) {
	$post = get_post( $post_id ? $post_id : get_the_ID() );
	if ( ! $post ) {
		return '';
	}
	$text = $post->post_excerpt ? $post->post_excerpt : strip_shortcodes( $post->post_content );
	$text = wp_strip_all_tags( $text );
	return wp_trim_words( $text, max( 1, absint( $length ) ), '…' );
}

/**
 * Echo image with native responsive WordPress sizes where possible.
 * First content image is a fallback; its original authorship is not changed.
 */
function pc_post_image( $size = 'pc-card', $args = array() ) {
	$args = wp_parse_args( $args, array( 'post_id' => get_the_ID(), 'class' => '', 'loading' => 'lazy' ) );
	$post_id = absint( $args['post_id'] );
	$loading = 'eager' === $args['loading'] ? 'eager' : 'lazy';
	$class_parts = preg_split( '/\s+/', (string) $args['class'], -1, PREG_SPLIT_NO_EMPTY );
	$class_parts = array_map( 'sanitize_html_class', $class_parts );
	$attrs = array(
		'class' => trim( 'pc-post-image ' . implode( ' ', $class_parts ) ),
		'loading' => $loading,
		'decoding' => 'async',
		'sizes' => '(max-width: 620px) 100vw, (max-width: 1000px) 50vw, 680px',
	);
	if ( 'pc-feature' === $size ) {
		$attrs['sizes'] = '(max-width: 900px) 100vw, 70vw';
	}
	if ( isset( $args['fetchpriority'] ) && 'high' === $args['fetchpriority'] ) {
		$attrs['fetchpriority'] = 'high';
	}
	$attachment_id = get_post_thumbnail_id( $post_id );
	if ( $attachment_id && wp_attachment_is_image( $attachment_id ) ) {
		if ( ! get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) ) {
			$attrs['alt'] = get_the_title( $post_id );
		}
		echo wp_get_attachment_image( $attachment_id, $size, false, $attrs ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress escapes image attributes.
		return;
	}
	$post = get_post( $post_id );
	$first = null;
	if ( $post && preg_match( '/<img\b[^>]*>/i', $post->post_content, $matches ) ) {
		$tag = $matches[0];
		if ( preg_match( '/\bsrc\s*=\s*([\'"])(.*?)\1/i', $tag, $source ) ) {
			$source = html_entity_decode( $source[2], ENT_QUOTES, 'UTF-8' );
			if ( preg_match( '~^https?://~i', $source ) && esc_url_raw( $source ) ) {
				$first = array( 'src' => esc_url_raw( $source ), 'alt' => '' );
				if ( preg_match( '/\balt\s*=\s*([\'"])(.*?)\1/i', $tag, $alt ) ) {
					$first['alt'] = sanitize_text_field( html_entity_decode( $alt[2], ENT_QUOTES, 'UTF-8' ) );
				}
				if ( preg_match( '/\bwp-image-(\d+)\b/i', $tag, $image_class ) ) {
					$id = absint( $image_class[1] );
					if ( wp_attachment_is_image( $id ) ) {
						echo wp_get_attachment_image( $id, $size, false, $attrs ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						return;
					}
				}
			}
		}
	}
	if ( $first ) {
		printf( '<img class="%1$s" src="%2$s" alt="%3$s" width="1400" height="900" loading="%4$s" decoding="async"%5$s>', esc_attr( $attrs['class'] ), esc_url( $first['src'] ), esc_attr( $first['alt'] ? $first['alt'] : get_the_title( $post_id ) ), esc_attr( $loading ), isset( $attrs['fetchpriority'] ) ? ' fetchpriority="high"' : '' );
		return;
	}
	$config = pc_category_config( pc_primary_category( $post_id ) );
	printf( '<img class="%1$s pc-post-image--fallback" src="%2$s" alt="" width="1400" height="900" loading="%3$s" decoding="async"%4$s>', esc_attr( $attrs['class'] ), esc_url( $config['image'] ), esc_attr( $loading ), isset( $attrs['fetchpriority'] ) ? ' fetchpriority="high"' : '' );
}

function pc_icon( $name, $class = '' ) {
	$paths = array(
		'search' => '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/>',
		'menu' => '<path d="M4 6h16M4 12h16M4 18h11"/>',
		'close' => '<path d="m6 6 12 12M18 6 6 18"/>',
		'arrow' => '<path d="M4 12h16m-6-6 6 6-6 6"/>',
		'clock' => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.5 2"/>',
		'chevron' => '<path d="m6 9 6 6 6-6"/>',
		'mail' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/>',
	);
	if ( ! isset( $paths[ $name ] ) ) {
		return '';
	}
	return '<svg class="pc-icon ' . esc_attr( $class ) . '" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $paths[ $name ] . '</svg>';
}

function pc_brand_markup( $inverse = false ) {
	$url = home_url( '/' );
	if ( has_custom_logo() ) {
		echo '<div class="pc-brand pc-brand--custom">' . get_custom_logo() . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress markup.
		return;
	}
	$logo_file = $inverse ? '/assets/images/logo-inverse.svg' : '/assets/images/logo.svg';
	$logo_path = get_theme_file_path( $logo_file );
	echo '<a class="pc-brand" href="' . esc_url( $url ) . '" aria-label="Primarius Club — página inicial">';
	if ( file_exists( $logo_path ) ) {
		echo '<img class="pc-brand-logo" src="' . esc_url( get_theme_file_uri( $logo_file ) ) . '" alt="Primarius Club" width="330" height="76" decoding="async">';
	} else {
		echo '<span class="pc-brand-name">Primarius <span>Club</span></span>';
	}
	echo '</a>';
}

/** Non-schema breadcrumbs: leave structured data to Yoast or another SEO plugin. */
function pc_breadcrumbs() {
	if ( is_front_page() ) {
		return;
	}
	echo '<nav class="pc-breadcrumbs" aria-label="Caminho de navegação"><a href="' . esc_url( home_url( '/' ) ) . '">Início</a><span aria-hidden="true">/</span>';
	if ( is_singular( 'post' ) ) {
		$category = pc_primary_category();
		if ( $category ) {
			echo '<a href="' . esc_url( get_category_link( $category ) ) . '">' . esc_html( $category->name ) . '</a><span aria-hidden="true">/</span>';
		}
		echo '<span aria-current="page">' . esc_html( get_the_title() ) . '</span>';
	} elseif ( is_category() ) {
		echo '<span aria-current="page">' . esc_html( single_cat_title( '', false ) ) . '</span>';
	} elseif ( is_search() ) {
		echo '<span aria-current="page">Busca</span>';
	} elseif ( is_404() ) {
		echo '<span aria-current="page">Página não encontrada</span>';
	} elseif ( is_page() ) {
		echo '<span aria-current="page">' . esc_html( get_the_title() ) . '</span>';
	} else {
		echo '<span aria-current="page">' . esc_html( wp_strip_all_tags( get_the_archive_title() ) ) . '</span>';
	}
	echo '</nav>';
}

/** Only public pages are linked; drafts are visible in the setup screen instead. */
function pc_institutional_pages() {
	$definitions = pc_page_definitions();
	$pages = array();
	foreach ( $definitions as $slug => $definition ) {
		$page = pc_existing_page( $slug, isset( $definition['aliases'] ) ? $definition['aliases'] : array() );
		if ( $page && 'publish' === $page->post_status ) {
			$pages[] = array( 'title' => $definition['title'], 'url' => get_permalink( $page ), 'id' => $page->ID, 'slug' => $slug );
		}
	}
	return $pages;
}
