<?php
/** Automatic editorial homepage: all recent posts remain reachable through pagination. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$pc_paged = max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
$pc_latest = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 12, 'paged' => $pc_paged, 'ignore_sticky_posts' => true, 'orderby' => 'date', 'order' => 'DESC' ) );
?>
<main id="main-content" class="site-main homepage">
	<div class="container">
		<header class="home-intro"><p class="eyebrow"><?php esc_html_e( 'Informação com contexto', 'primarius-club' ); ?></p><h1><?php esc_html_e( 'Curiosidade para descobrir. Clareza para entender.', 'primarius-club' ); ?></h1><p><?php esc_html_e( 'Ideias, descobertas e assuntos do cotidiano para ampliar o seu olhar.', 'primarius-club' ); ?></p></header>
		<?php if ( $pc_latest->have_posts() ) : ?>
			<?php if ( 1 === $pc_paged ) : ?>
				<section class="section featured-section" aria-label="<?php esc_attr_e( 'Publicações em destaque', 'primarius-club' ); ?>">
					<div class="hero-grid">
					<?php $pc_feature_count = min( 3, (int) $pc_latest->post_count ); for ( $pc_index = 0; $pc_index < $pc_feature_count; $pc_index++ ) : $pc_latest->the_post(); ?>
						<?php get_template_part( 'template-parts/post-card', null, array( 'variant' => 0 === $pc_index ? 'lead' : 'compact', 'heading' => 'h2', 'excerpt' => 0 === $pc_index, 'eager' => 0 === $pc_index ) ); ?>
					<?php endfor; ?>
					</div>
				</section>
			<?php endif; ?>
			<?php if ( $pc_latest->have_posts() ) : ?>
			<section class="section latest-section" aria-labelledby="latest-title">
				<div class="section-heading"><div><span class="eyebrow"><?php esc_html_e( 'O que há de novo', 'primarius-club' ); ?></span><h2 id="latest-title"><?php echo esc_html( 1 === $pc_paged ? __( 'Últimas publicações', 'primarius-club' ) : __( 'Mais publicações', 'primarius-club' ) ); ?></h2></div><span class="section-note"><?php esc_html_e( 'Uma leitura, novas possibilidades.', 'primarius-club' ); ?></span></div>
				<div class="latest-grid">
				<?php while ( $pc_latest->have_posts() ) : $pc_latest->the_post(); get_template_part( 'template-parts/post-card' ); endwhile; ?>
				</div>
			</section>
			<?php endif; ?>
			<?php if ( $pc_latest->max_num_pages > 1 ) : ?><nav class="pagination" aria-label="<?php esc_attr_e( 'Paginação das publicações', 'primarius-club' ); ?>"><?php echo wp_kses_post( paginate_links( array( 'base' => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ), 'format' => '?paged=%#%', 'current' => $pc_paged, 'total' => $pc_latest->max_num_pages, 'prev_text' => __( '← Anteriores', 'primarius-club' ), 'next_text' => __( 'Próximas →', 'primarius-club' ), 'type' => 'list' ) ) ); ?></nav><?php endif; ?>
			<?php wp_reset_postdata(); ?>
		<?php else : get_template_part( 'template-parts/empty' ); endif; ?>
	</div>
	<?php if ( 1 === $pc_paged ) : ?>
		<?php foreach ( pc_categories() as $pc_key => $pc_config ) : ?>
			<?php
			$pc_terms = pc_category_terms( $pc_key );
			if ( empty( $pc_terms ) ) { continue; }
			$pc_term_ids = array_map( 'intval', wp_list_pluck( $pc_terms, 'term_id' ) );
			$pc_category_posts = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 3, 'ignore_sticky_posts' => true, 'no_found_rows' => true, 'tax_query' => array( array( 'taxonomy' => 'category', 'field' => 'term_id', 'terms' => $pc_term_ids, 'include_children' => true ) ) ) );
			?>
			<section class="section category-section" data-category="<?php echo esc_attr( $pc_config['slug'] ); ?>" style="--category-accent:<?php echo esc_attr( $pc_config['accent'] ); ?>;--category-tint:<?php echo esc_attr( $pc_config['tint'] ); ?>" aria-labelledby="category-<?php echo esc_attr( $pc_config['slug'] ); ?>">
				<div class="container">
					<div class="category-section__header"><div><span class="eyebrow"><?php esc_html_e( 'Explore o assunto', 'primarius-club' ); ?></span><h2 id="category-<?php echo esc_attr( $pc_config['slug'] ); ?>"><?php echo esc_html( $pc_config['label'] ); ?></h2><p><?php echo esc_html( $pc_config['description'] ); ?></p></div><a class="text-link" href="<?php echo esc_url( pc_category_link( $pc_key ) ); ?>"><?php esc_html_e( 'Ver categoria', 'primarius-club' ); ?> <?php echo pc_icon( 'arrow' ); ?></a><img class="category-section__art" src="<?php echo esc_url( $pc_config['image'] ); ?>" alt="" width="240" height="180" loading="lazy" aria-hidden="true"></div>
					<?php if ( $pc_category_posts->have_posts() ) : ?><div class="category-grid"><?php while ( $pc_category_posts->have_posts() ) : $pc_category_posts->the_post(); get_template_part( 'template-parts/post-card' ); endwhile; ?></div><?php else : ?><p class="category-empty"><?php esc_html_e( 'As próximas publicações deste assunto aparecerão aqui.', 'primarius-club' ); ?></p><?php endif; ?>
				</div>
			</section>
			<?php wp_reset_postdata(); ?>
		<?php endforeach; ?>
	<?php endif; ?>
</main>
<?php get_footer(); ?>
