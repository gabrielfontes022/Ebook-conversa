<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$pc_term = get_queried_object();
$pc_config = pc_category_config( $pc_term );
$pc_description = term_description();
?>
<main id="main-content" class="site-main category-main" data-category="<?php echo esc_attr( $pc_config['slug'] ); ?>" style="--category-accent:<?php echo esc_attr( $pc_config['accent'] ); ?>;--category-tint:<?php echo esc_attr( $pc_config['tint'] ); ?>">
	<section class="category-hero"><div class="container"><div class="category-hero__content"><?php pc_breadcrumbs(); ?><p class="eyebrow"><?php esc_html_e( 'Um assunto, novas perspectivas', 'primarius-club' ); ?></p><h1><?php single_cat_title(); ?></h1><div class="category-description"><?php echo $pc_description ? wp_kses_post( $pc_description ) : '<p>' . esc_html( $pc_config['description'] ) . '</p>'; ?></div></div><img class="category-hero__art" src="<?php echo esc_url( $pc_config['image'] ); ?>" width="480" height="360" alt="" aria-hidden="true" fetchpriority="low"></div></section>
	<div class="container section"><div class="section-heading"><h2><?php esc_html_e( 'Publicações da categoria', 'primarius-club' ); ?></h2><span class="section-note"><?php esc_html_e( 'Mais recentes primeiro', 'primarius-club' ); ?></span></div>
	<?php if ( have_posts() ) : ?><div class="archive-grid"><?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/post-card' ); endwhile; ?></div><?php the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => __( '← Anteriores', 'primarius-club' ), 'next_text' => __( 'Próximas →', 'primarius-club' ) ) ); else : get_template_part( 'template-parts/empty' ); endif; ?>
	</div>
</main>
<?php get_footer(); ?>
