<?php
/** Site header. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<noscript><style>.site-nav .nav-panel{display:block!important}.menu-toggle,[data-search-toggle]{display:none!important}</style></noscript>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#main-content"><?php esc_html_e( 'Pular para o conteúdo', 'primarius-club' ); ?></a>
<header class="site-header">
	<div class="container header-main">
		<div class="brand"><?php pc_brand_markup(); ?></div>
		<p class="header-tagline"><?php echo esc_html( get_bloginfo( 'description' ) ? get_bloginfo( 'description' ) : __( 'Ideias que ampliam seu mundo.', 'primarius-club' ) ); ?></p>
		<div class="header-tools">
			<button class="icon-button" type="button" data-search-toggle aria-expanded="false" aria-controls="pc-search-panel" aria-label="<?php esc_attr_e( 'Abrir busca', 'primarius-club' ); ?>"><?php echo pc_icon( 'search' ); ?><span class="tool-label"><?php esc_html_e( 'Buscar', 'primarius-club' ); ?></span></button>
			<button class="icon-button menu-toggle" type="button" data-menu-toggle aria-expanded="false" aria-controls="pc-nav-panel" aria-label="<?php esc_attr_e( 'Abrir menu de categorias', 'primarius-club' ); ?>"><?php echo pc_icon( 'menu' ); ?></button>
		</div>
	</div>
	<div id="pc-search-panel" class="search-panel" data-search-panel hidden>
		<div class="container"><?php get_search_form(); ?></div>
	</div>
	<noscript><div class="container header-search"><?php get_search_form(); ?></div></noscript>
	<nav class="site-nav" aria-label="<?php esc_attr_e( 'Navegação principal', 'primarius-club' ); ?>">
		<div id="pc-nav-panel" class="container nav-panel" data-menu-panel>
			<?php if ( has_nav_menu( 'primary' ) ) : ?>
				<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'primary-menu', 'menu_id' => 'primary-menu', 'depth' => 2, 'fallback_cb' => false ) ); ?>
			<?php else : ?>
				<ul class="primary-menu">
					<li<?php echo is_front_page() ? ' class="current-menu-item"' : ''; ?>><a href="<?php echo esc_url( home_url( '/' ) ); ?>"<?php echo is_front_page() ? ' aria-current="page"' : ''; ?>><?php esc_html_e( 'Início', 'primarius-club' ); ?></a></li>
					<?php foreach ( pc_categories() as $pc_key => $pc_config ) : ?>
						<?php $pc_active = is_category() && pc_category_config( get_queried_object() )['slug'] === $pc_config['slug']; ?>
						<li<?php echo $pc_active ? ' class="current-menu-item"' : ''; ?>><a href="<?php echo esc_url( pc_category_link( $pc_key ) ); ?>"<?php echo $pc_active ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $pc_config['label'] ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
	</nav>
</header>
