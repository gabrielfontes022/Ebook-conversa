<?php
/** Site footer; unpublished institutional pages are never linked publicly. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$pc_footer_pages = pc_institutional_pages();
?>
<footer class="site-footer">
	<div class="container footer-grid">
		<div class="footer-brand">
			<div class="brand"><?php pc_brand_markup( true ); ?></div>
			<p><?php esc_html_e( 'Informação com contexto. Ciência, ideias e assuntos do cotidiano para ampliar o seu olhar.', 'primarius-club' ); ?></p>
		</div>
		<div class="footer-categories">
			<h2><?php esc_html_e( 'Explore os assuntos', 'primarius-club' ); ?></h2>
			<ul><?php foreach ( pc_categories() as $pc_key => $pc_config ) : ?><li><a href="<?php echo esc_url( pc_category_link( $pc_key ) ); ?>"><?php echo esc_html( $pc_config['label'] ); ?></a></li><?php endforeach; ?></ul>
		</div>
		<nav class="footer-institutional" aria-label="<?php esc_attr_e( 'Informações institucionais', 'primarius-club' ); ?>">
			<h2><?php esc_html_e( 'Primarius Club', 'primarius-club' ); ?></h2>
			<?php if ( has_nav_menu( 'footer' ) ) : ?>
				<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'depth' => 1, 'fallback_cb' => false ) ); ?>
			<?php else : ?>
				<ul>
				<?php foreach ( $pc_footer_pages as $pc_page ) : ?><li><a href="<?php echo esc_url( $pc_page['url'] ); ?>"><?php echo esc_html( $pc_page['title'] ); ?></a></li><?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</nav>
	</div>
	<div class="container footer-bottom">
		<p>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?>. <?php esc_html_e( 'Todos os direitos reservados.', 'primarius-club' ); ?></p>
		<a href="#main-content"><?php esc_html_e( 'Voltar ao conteúdo', 'primarius-club' ); ?> <span aria-hidden="true">↑</span></a>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
