(function(){
  'use strict';
  var menuButton=document.querySelector('[data-menu-toggle]');
  var menuPanel=document.querySelector('[data-menu-panel]');
  var searchButton=document.querySelector('[data-search-toggle]');
  var searchPanel=document.querySelector('[data-search-panel]');
  function setMenu(open){
    if(!menuButton||!menuPanel)return;
    menuButton.setAttribute('aria-expanded',String(open));
    menuButton.setAttribute('aria-label',open?'Fechar menu de categorias':'Abrir menu de categorias');
    menuPanel.classList.toggle('is-open',open);
    document.body.classList.toggle('menu-open',open&&window.matchMedia('(max-width:820px)').matches);
  }
  function setSearch(open,focus){
    if(!searchButton||!searchPanel)return;
    searchButton.setAttribute('aria-expanded',String(open));
    searchButton.setAttribute('aria-label',open?'Fechar busca':'Abrir busca');
    searchPanel.hidden=!open;
    if(open&&focus){var input=searchPanel.querySelector('input[type="search"]');if(input)input.focus();}
  }
  if(menuButton&&menuPanel)menuButton.addEventListener('click',function(){var open=menuButton.getAttribute('aria-expanded')!=='true';setSearch(false,false);setMenu(open);});
  if(searchButton&&searchPanel)searchButton.addEventListener('click',function(){var open=searchButton.getAttribute('aria-expanded')!=='true';setMenu(false);setSearch(open,true);});
  document.addEventListener('keydown',function(event){
    if(event.key==='Escape'){
      var menuWasOpen=menuButton&&menuButton.getAttribute('aria-expanded')==='true';
      var searchWasOpen=searchButton&&searchButton.getAttribute('aria-expanded')==='true';
      setMenu(false);setSearch(false,false);
      if(menuWasOpen)menuButton.focus();else if(searchWasOpen)searchButton.focus();
    }
  });
  var media=window.matchMedia('(min-width:821px)');
  function resetOnDesktop(event){if(event.matches)setMenu(false);}
  if(media.addEventListener)media.addEventListener('change',resetOnDesktop);else if(media.addListener)media.addListener(resetOnDesktop);
})();
