<?php
/**
 * Primarius Club Editorial: theme bootstrap.
 *
 * @package Primarius_Club
 */

defined( 'ABSPATH' ) || exit;

define( 'PC_THEME_VERSION', '1.0.0' );

require_once get_template_directory() . '/inc/categories.php';
require_once get_template_directory() . '/inc/helpers.php';
require_once get_template_directory() . '/inc/setup.php';
require_once get_template_directory() . '/inc/pages.php';
require_once get_template_directory() . '/inc/contact.php';
require_once get_template_directory() . '/inc/admin.php';
