<?php
/**
 * Template Name: Página de contato
 * Template Post Type: page
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main id="main-content" class="site-main page-main"><div class="container">
<?php while ( have_posts() ) : the_post(); ?>
	<article <?php post_class( 'institutional-page contact-page' ); ?>>
		<header class="article-header"><?php pc_breadcrumbs(); ?><span class="eyebrow"><?php esc_html_e( 'Uma conversa começa aqui', 'primarius-club' ); ?></span><h1><?php the_title(); ?></h1></header>
		<div class="article-content entry-content"><?php the_content(); ?></div>
		<?php if ( ! preg_match( '/<form\b|<!--\s+wp:(?:contact-form-7|jetpack\/contact-form|wpforms|forminator)|\[(?:pc_contact|contact-form-7|wpforms|forminator_form|ninja_form|gravityform)\b/i', get_the_content() ) ) { pc_contact_form(); } ?>
	</article>
<?php endwhile; ?>
</div></main>
<?php get_footer(); ?>
