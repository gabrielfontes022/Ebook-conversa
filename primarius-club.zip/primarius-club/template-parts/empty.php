<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="empty-state">
	<span class="eyebrow"><?php esc_html_e( 'Novas perspectivas', 'primarius-club' ); ?></span>
	<h2><?php esc_html_e( 'As próximas descobertas começam aqui.', 'primarius-club' ); ?></h2>
	<p><?php esc_html_e( 'Ainda não há publicações nesta seleção. Explore os outros assuntos do blog ou faça uma pesquisa.', 'primarius-club' ); ?></p>
	<?php get_search_form(); ?>
</div>
