<?php
/** A post card. Receives variant, excerpt, heading, eager via get_template_part args. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$pc_variant = isset( $args['variant'] ) ? sanitize_html_class( $args['variant'] ) : 'default';
$pc_show_excerpt = isset( $args['excerpt'] ) ? (bool) $args['excerpt'] : 'compact' !== $pc_variant;
$pc_heading = isset( $args['heading'] ) && in_array( $args['heading'], array( 'h2', 'h3' ), true ) ? $args['heading'] : 'h3';
$pc_eager = ! empty( $args['eager'] );
$pc_term = pc_primary_category();
$pc_config = pc_category_config( $pc_term );
?>
<article <?php post_class( 'post-card post-card--' . $pc_variant ); ?> data-category="<?php echo esc_attr( $pc_config['slug'] ); ?>" style="--category-accent:<?php echo esc_attr( $pc_config['accent'] ); ?>">
	<a class="post-card__image" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true"><?php pc_post_image( 'lead' === $pc_variant ? 'pc-feature' : 'pc-card', array( 'loading' => $pc_eager ? 'eager' : 'lazy', 'fetchpriority' => $pc_eager ? 'high' : 'auto' ) ); ?></a>
	<div class="post-card__body">
		<?php if ( $pc_term ) : ?><a class="category-chip" href="<?php echo esc_url( get_category_link( $pc_term ) ); ?>"><?php echo esc_html( $pc_term->name ); ?></a><?php endif; ?>
		<<?php echo $pc_heading; ?> class="post-card__title"><a href="<?php the_permalink(); ?>"><?php echo esc_html( get_the_title() ); ?></a></<?php echo $pc_heading; ?>>
		<?php if ( $pc_show_excerpt ) : ?><p class="post-card__excerpt"><?php echo esc_html( pc_excerpt( 'lead' === $pc_variant ? 28 : 21 ) ); ?></p><?php endif; ?>
		<div class="post-card__meta"><time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time><span aria-hidden="true">·</span><span><?php echo esc_html( sprintf( __( '%d min de leitura', 'primarius-club' ), pc_reading_time() ) ); ?></span></div>
	</div>
</article>
