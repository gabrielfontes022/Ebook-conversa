<?php if ( ! defined( 'ABSPATH' ) ) { exit; } get_header(); ?>
<main id="main-content" class="site-main single-main">
<?php while ( have_posts() ) : the_post(); $pc_term = pc_primary_category(); $pc_config = pc_category_config( $pc_term ); ?>
	<article <?php post_class( 'single-article' ); ?> data-category="<?php echo esc_attr( $pc_config['slug'] ); ?>" style="--category-accent:<?php echo esc_attr( $pc_config['accent'] ); ?>">
		<header class="container article-header"><?php pc_breadcrumbs(); ?><?php if ( $pc_term ) : ?><a class="category-chip" href="<?php echo esc_url( get_category_link( $pc_term ) ); ?>"><?php echo esc_html( $pc_term->name ); ?></a><?php endif; ?><h1><?php the_title(); ?></h1><?php if ( has_excerpt() ) : ?><p class="article-deck"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?><div class="article-meta"><span><?php echo esc_html( sprintf( __( 'Por %s', 'primarius-club' ), get_the_author() ) ); ?></span><time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time><?php if ( get_the_modified_time( 'U' ) > get_the_time( 'U' ) + DAY_IN_SECONDS ) : ?><span><?php echo esc_html( sprintf( __( 'Atualizado em %s', 'primarius-club' ), get_the_modified_date() ) ); ?></span><?php endif; ?><span><?php echo esc_html( sprintf( __( '%d min de leitura', 'primarius-club' ), pc_reading_time() ) ); ?></span></div></header>
		<figure class="container article-cover"><?php pc_post_image( 'pc-feature', array( 'loading' => 'eager', 'fetchpriority' => 'high' ) ); ?><?php $pc_caption = has_post_thumbnail() ? wp_get_attachment_caption( get_post_thumbnail_id() ) : ''; if ( $pc_caption ) : ?><figcaption><?php echo wp_kses_post( $pc_caption ); ?></figcaption><?php endif; ?></figure>
		<div class="container reading-layout"><div class="article-content entry-content"><?php the_content(); wp_link_pages( array( 'before' => '<nav class="page-links" aria-label="' . esc_attr__( 'Páginas do artigo', 'primarius-club' ) . '">', 'after' => '</nav>' ) ); ?><?php if ( has_tag() ) : ?><div class="article-tags"><?php the_tags( '<span>' . esc_html__( 'Assuntos relacionados:', 'primarius-club' ) . '</span> ', ', ' ); ?></div><?php endif; ?></div><aside class="sidebar-note"><span class="eyebrow"><?php esc_html_e( 'Continue explorando', 'primarius-club' ); ?></span><h2><?php esc_html_e( 'Um assunto leva a outro.', 'primarius-club' ); ?></h2><p><?php esc_html_e( 'Explore outras perspectivas e encontre a sua próxima leitura nas categorias do blog.', 'primarius-club' ); ?></p><?php if ( $pc_term ) : ?><a class="text-link" href="<?php echo esc_url( get_category_link( $pc_term ) ); ?>"><?php echo esc_html( $pc_term->name ); ?> <?php echo pc_icon( 'arrow' ); ?></a><?php endif; ?></aside></div>
	</article>
	<?php if ( is_active_sidebar( 'after-content' ) ) : ?><div class="container after-content-widgets"><?php dynamic_sidebar( 'after-content' ); ?></div><?php endif; ?>
	<?php
	$pc_related_args = array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 3, 'post__not_in' => array( get_the_ID() ), 'ignore_sticky_posts' => true, 'no_found_rows' => true );
	if ( $pc_term ) { $pc_related_args['category__in'] = array( (int) $pc_term->term_id ); }
	$pc_related = new WP_Query( $pc_related_args );
	if ( $pc_related->have_posts() ) : ?>
	<section class="container section related-section" aria-labelledby="related-title"><div class="section-heading"><h2 id="related-title"><?php esc_html_e( 'Sua próxima leitura', 'primarius-club' ); ?></h2></div><div class="category-grid"><?php while ( $pc_related->have_posts() ) : $pc_related->the_post(); get_template_part( 'template-parts/post-card' ); endwhile; ?></div></section>
	<?php endif; wp_reset_postdata(); ?>
	<?php if ( comments_open() || get_comments_number() ) : ?><div class="container comments-wrap"><?php comments_template(); ?></div><?php endif; ?>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
