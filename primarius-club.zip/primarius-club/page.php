<?php if ( ! defined( 'ABSPATH' ) ) { exit; } get_header(); ?>
<main id="main-content" class="site-main page-main"><div class="container">
<?php while ( have_posts() ) : the_post(); ?>
	<article <?php post_class( 'institutional-page' ); ?>>
		<header class="article-header"><?php pc_breadcrumbs(); ?><span class="eyebrow"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span><h1><?php the_title(); ?></h1></header>
		<div class="article-content entry-content"><?php the_content(); wp_link_pages(); ?></div>
		<?php $pc_content = get_the_content(); if ( in_array( get_post_field( 'post_name', get_the_ID() ), array( 'contato', 'contact', 'fale-conosco' ), true ) && ! preg_match( '/<form\b|<!--\s+wp:(?:contact-form-7|jetpack\/contact-form|wpforms|forminator)|\[(?:pc_contact|contact-form-7|wpforms|forminator_form|ninja_form|gravityform)\b/i', $pc_content ) ) { pc_contact_form(); } ?>
	</article>
<?php endwhile; ?>
</div></main>
<?php get_footer(); ?>
