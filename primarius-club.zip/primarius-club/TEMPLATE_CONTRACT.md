# Templates: contrato para CSS e JavaScript

Todas as páginas usam `.site-header`, `.site-main#main-content`, `.site-footer` e `.container`. A home usa `.hero-grid` (primeiro filho lead e até dois compact), `.latest-grid` e sete `.category-section` quando os termos existem. Cada faixa usa `.category-section__header`, `.category-section__art`, `.category-grid`. Cards: `.post-card`, `--lead`, `--compact`, `__image`, `__body`, `__title`, `__excerpt`, `__meta`. Categoria e cards expõem `data-category` e `--category-accent`; faixas/capas também `--category-tint`.

JS: `[data-menu-toggle]` controla `[data-menu-panel]#pc-nav-panel`, sem `hidden` inicial para funcionar sem JS. `[data-search-toggle]` controla `[data-search-panel]#pc-search-panel`, com `hidden` inicial; há formulário noscript. Atualizar aria-expanded, rótulos e fechar com Escape. Menus WordPress usam `.primary-menu`, `.sub-menu`, `.current-menu-item`. `.icon-button.menu-toggle` só deve aparecer no breakpoint compacto. Foco visível e alvos de toque >=44px.

Arquivos: single usa `.article-header`, `.article-meta`, `.article-deck`, `.article-cover`, `.reading-layout`, `.article-content.entry-content`, `.sidebar-note`, `.related-section`; páginas `.institutional-page` e `.contact-page`; arquivos `.archive-header`, `.archive-grid`; busca `.search-form`, `.search-field-wrap`, `.search-field`, `.search-submit`; rodapé `.footer-grid`, `.footer-brand`, `.footer-categories`, `.footer-institutional`, `.footer-bottom`. Estilizar paginação WordPress `.navigation.pagination`, `.nav-links`, `.page-numbers` além de `.pagination`.

Helpers do core: `pc_brand_markup()`, `pc_post_image()`, `pc_breadcrumbs()`, `pc_contact_form()` imprimem; `pc_icon()` retorna SVG; `pc_excerpt()` retorna string; `pc_reading_time()` retorna inteiro; `pc_category_terms()` retorna WP_Term[].

A home consulta 12 posts por página. Na primeira página, 3 formam destaque e os 9 seguintes formam grade. Nas páginas seguintes, os 12 formam grade. Assim não há lacunas nem duplicação dentro da seleção recente. As faixas temáticas deliberadamente reapresentam posts no contexto da categoria. Cada faixa tem consulta limitada a 3 posts, sem contagem de páginas; arquivos de categoria e busca preservam a main query do WordPress.

Páginas institucionais do rodapé só são ligadas automaticamente quando publicadas. Menus customizados continuam sob controle do administrador. Não são criados posts demonstrativos pelos templates. Conteúdo de posts e páginas é preservado via `the_content()`.
