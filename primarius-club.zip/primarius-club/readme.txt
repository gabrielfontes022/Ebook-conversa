=== Primarius Club Editorial ===
Contributors: gabrielfontes022
Requires at least: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Tema editorial original para o Primarius Club. A implementação usa o WordPress
nativo, texto, CSS e pequenos SVG locais. Não há carrossel, construtor de páginas,
fonte remota, biblioteca JavaScript externa ou rastreador incluído pelo tema.

== Instalação ==

1. No WordPress, acesse Aparência > Temas > Adicionar novo > Enviar tema.
2. Envie o arquivo primarius-club.zip e instale. A prévia pode ser conferida antes
   de ativar. A instalação do ZIP não exige colar código no editor do Blogger.
3. Depois de ativar, acesse Aparência > Primarius Club. Confira responsável,
   e-mail e serviços. Use 'Preparar estrutura sem substituir conteúdo'.
4. Revise os rascunhos institucionais e publique os textos depois de conferir
   que correspondem aos recursos realmente utilizados no seu site.

== Conteúdo e categorias ==

Escreva em Posts > Adicionar novo. Selecione a categoria, o resumo e uma imagem
destacada. Ao publicar, a capa, as grades e os arquivos do WordPress são
atualizados automaticamente. Não é necessário editar o tema a cada publicação.

Categorias: Casa e Jardim; Ciência; Concursos Públicos; Inovação Tecnológica;
Negócios; Política; Viral. Os nomes alternativos mais comuns são reconhecidos
sem migrar ou apagar posts. O painel pode criar as categorias que faltam.

A primeira página mostra 12 publicações recentes, sendo até 3 em destaque.
As demais permanecem acessíveis pela paginação. Há também faixas temáticas.
Os arquivos de categoria usam a própria consulta e paginação do WordPress.

A imagem destacada é priorizada. Sem ela, o tema procura a primeira imagem do
conteúdo. Se nenhuma existir, usa uma ilustração vetorial da categoria. Créditos
e legendas dos materiais existentes não são alterados pelo tema.

== Páginas institucionais ==

A preparação cria apenas o que não existe. Sobre e Contato são publicadas
quando novas. Privacidade, Cookies, Termos de Uso e Política Editorial são
preparadas como rascunhos para revisão. Conteúdo existente não é sobrescrito.

Dados iniciais editáveis: Gabriel Fontes; primariusclub@gmail.com.
AdSense e Analytics começam como 'Ainda não confirmado'. Esses campos ajustam
as declarações institucionais, sem instalar scripts ou serviços externos.

O rodapé liga somente páginas públicas. Depois de revisar e publicar a política
de privacidade, selecione-a no WordPress ou no painel do tema.

== Contato ==

O formulário nativo usa wp_mail e o transporte de e-mail da sua hospedagem.
Faça um envio de teste e confira a caixa de destino e o spam. Uma aceitação
pelo sistema de envio não comprova entrega na caixa postal. Se necessário,
configure o serviço de e-mail/SMTP do WordPress com seu provedor.

É possível usar o shortcode de um plugin de formulário já instalado, no campo
opcional do painel do tema. Não insira credenciais de e-mail no tema.

== Aparência e compatibilidade ==

Aparência > Personalizar permite trocar a identidade visual do WordPress.
Menus próprios podem ser associados às posições Navegação principal e Links
do rodapé. Sem menus personalizados, as categorias e páginas são listadas
automaticamente. A busca e os comentários usam os recursos nativos do sistema.

O tema preserva wp_head, wp_footer e title-tag para integração com plugins
como Yoast. Não duplica dados estruturados de SEO nem insere anúncios.

Se os posts existentes usarem construtores, shortcodes ou blocos de plugins,
mantenha esses plugins ativos. O tema não substitui suas funcionalidades.

== Desempenho ==

CSS e JavaScript são locais e compactos. Não há fontes remotas. Imagens da
biblioteca usam os recursos responsivos nativos do WordPress e dimensões
definidas; imagens abaixo da abertura recebem carregamento tardio.

Imagens antigas podem não ter os tamanhos novos do tema. O WordPress poderá
usar um tamanho já existente; para obter as novas miniaturas, gere-as com um
recurso confiável da sua hospedagem/biblioteca de mídia, se necessário.

O tamanho das fotos, cache, hospedagem e plugins também influenciam a carga.
O tema não promete uma nota de desempenho, ranqueamento ou aprovação no AdSense.

== Licenças ==

Código: GPLv2 ou posterior. Ilustrações vetoriais criadas para este projeto.
A marca em contornos utiliza EB Garamond, sob SIL Open Font License, incluída
em assets/images/EBGaramond-OFL.txt. A fonte não é carregada pelo navegador.
Consulte ASSETS.md para detalhes. Fotografias dos posts pertencem aos seus
respectivos titulares e não estão incluídas como conteúdo demonstrativo.

== Changelog ==

= 1.0.0 =
Primeira versão: capa automática, sete identidades de categoria, arquivos,
busca, artigos, páginas institucionais, contato e identidade vetorial local.
